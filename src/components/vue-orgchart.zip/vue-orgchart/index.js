import OrgChart from './OrganizationChartContainer.vue'

OrgChart.install = (Vue) => {
  Vue.component('OrgChart', OrgChart)
}
export default OrgChart
